<html>
<head>
<link rel="stylesheet" href="style20.css">  
</head>
<body>
<?php
   echo "this is form page1" ;
  ?